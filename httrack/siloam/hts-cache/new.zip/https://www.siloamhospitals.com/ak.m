<!DOCTYPE html>
<html lang="en" translate="no">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta HTTP-EQUIV="Content-Language" content="ID">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1">
    <title>Rumah Sakit dengan Pelayanan Berkualitas - Siloam Hospitals</title>

    <meta name="color-scheme" content="light only">
    <!-- Add to home screen for Android and modern mobile browsers -->
    <meta name="theme-color" content="#1e266d">
    <!-- Add to home screen for Safari on iOS -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="#1e266d">
    <meta name="apple-mobile-web-app-title" content="Siloam Hospitals">
    <!-- Add to home screen for Windows -->
    <meta name="msapplication-TileColor" content="#1e266d">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link defer href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,200;0,400;0,500;0,700;0,800;0,900;1,200;1,400;1,500;1,700;1,800;1,900&display=swap" rel="stylesheet"> 
    <!-- Facebook Pixel Code -->
    <meta name="facebook-domain-verification" content="bs1twv03d6arvgny1bdw8vvi8g1mgw" />

    <!-- anti-flicker snippet (recommended)  -->
    <!-- <style>.async-hide { opacity: 0 !important} </style>
    <script>(function(a,s,y,n,c,h,i,d,e){s.className+=' '+y;h.start=1*new Date;
    h.end=i=function(){s.className=s.className.replace(RegExp(' ?'+y),'')};
    (a[n]=a[n]||[]).hide=h;setTimeout(function(){i();h.end=null},c);h.timeout=c;
    })(window,document.documentElement,'async-hide','dataLayer',4000,
    {'CONTAINER_ID': 'undefined'});</script> -->
      <script defer>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','GTM-N8B7PRZ');</script>
        <!-- End Google Tag Manager -->
        <!-- Hotjar Tracking Code for https://www.siloamhospitals.com -->
      <script defer>
        (function(h,o,t,j,a,r){
            h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
            h._hjSettings={hjid:2572891,hjsv:6};
            a=o.getElementsByTagName('head')[0];
            r=o.createElement('script');r.async=1;
            r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
            a.appendChild(r);
        })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
      </script>
      <script type="text/javascript"
      src="https://app.midtrans.com/snap/snap.js"></script>
      <!-- <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
      <script>
        window.OneSignal = window.OneSignal || [];
        OneSignal.push(function() {
          OneSignal.init({
            appId: "0b146aa0-572c-4391-9b4f-49b2f26ff7dd",
            notifyButton: {
              enable: true
            }
          });
        });
      </script> -->
    <script type="module" crossorigin src="/assets/index-babce878.js"></script>
    <link rel="modulepreload" crossorigin href="/assets/vendor-4bbde3a5.js">
    <link rel="stylesheet" href="/assets/index-54554b4d.css">
  
                              <script>!function(a){var e="https://s.go-mpulse.net/boomerang/",t="addEventListener";if("False"=="True")a.BOOMR_config=a.BOOMR_config||{},a.BOOMR_config.PageParams=a.BOOMR_config.PageParams||{},a.BOOMR_config.PageParams.pci=!0,e="https://s2.go-mpulse.net/boomerang/";if(window.BOOMR_API_key="BQD73-L72QN-LW4D7-G27MN-FCM4Q",function(){function n(e){a.BOOMR_onload=e&&e.timeStamp||(new Date).getTime()}if(!a.BOOMR||!a.BOOMR.version&&!a.BOOMR.snippetExecuted){a.BOOMR=a.BOOMR||{},a.BOOMR.snippetExecuted=!0;var i,_,o,r=document.createElement("iframe");if(a[t])a[t]("load",n,!1);else if(a.attachEvent)a.attachEvent("onload",n);r.src="javascript:void(0)",r.title="",r.role="presentation",(r.frameElement||r).style.cssText="width:0;height:0;border:0;display:none;",o=document.getElementsByTagName("script")[0],o.parentNode.insertBefore(r,o);try{_=r.contentWindow.document}catch(O){i=document.domain,r.src="javascript:var d=document.open();d.domain='"+i+"';void(0);",_=r.contentWindow.document}_.open()._l=function(){var a=this.createElement("script");if(i)this.domain=i;a.id="boomr-if-as",a.src=e+"BQD73-L72QN-LW4D7-G27MN-FCM4Q",BOOMR_lstart=(new Date).getTime(),this.body.appendChild(a)},_.write("<bo"+'dy onload="document._l();">'),_.close()}}(),"".length>0)if(a&&"performance"in a&&a.performance&&"function"==typeof a.performance.setResourceTimingBufferSize)a.performance.setResourceTimingBufferSize();!function(){if(BOOMR=a.BOOMR||{},BOOMR.plugins=BOOMR.plugins||{},!BOOMR.plugins.AK){var e=""=="true"?1:0,t="",n="wt42j3lwmjy4qzbpq2jq-f-da5b092cd-clientnsv4-s.akamaihd.net",i="false"=="true"?2:1,_={"ak.v":"34","ak.cp":"1099772","ak.ai":parseInt("655859",10),"ak.ol":"0","ak.cr":86,"ak.ipv":4,"ak.proto":"http/1.1","ak.rid":"16960681","ak.r":40224,"ak.a2":e,"ak.m":"b","ak.n":"ff","ak.bpcip":"180.249.164.0","ak.cport":13184,"ak.gh":"118.98.113.196","ak.quicv":"","ak.tlsv":"tls1.2","ak.0rtt":"","ak.csrc":"-","ak.acc":"bbr","ak.t":"1680836243","ak.ak":"hOBiQwZUYzCg5VSAfCLimQ==hxVorZEJJXB9imN6+RZuXjF6+ZF3exFOFt9avImf7UCMhXuSx/8GF7YMhwZuezhEWDjPRaACSHrUdds1wGXgV98kLrP8VHNMr8XvAW5NOUyigy1/PsN74Yn+cPqp/0if2WdCZyN06O6oWoOlsbmERJilEtWvUyMqpjGmvp8hyskDxFHqbC9mXBul/KI/VvGPKuId/FtQYNPoI8Wpn+75BSJ2oTWErc74G5mhdC2LlhYqCsN4nFyjajoCNen3IkqLKdaODmbdSeaej/DihbcmZbnSJnXPl5gFt/XUi85al9duo2UiYzIdpotwRs0D/0pF+G8kCgKzhCtn1cjLshnT7bIfz2IFb5qVHDityJNhZw/1M+QfaOmg8kwYXiebW/B8CHjeeuyN6ofSa6l+WZUGyIPuw1pGsl91ZXr/hE65ebE=","ak.pv":"17","ak.dpoabenc":"","ak.tf":i};if(""!==t)_["ak.ruds"]=t;var o={i:!1,av:function(e){var t="http.initiator";if(e&&(!e[t]||"spa_hard"===e[t]))_["ak.feo"]=void 0!==a.aFeoApplied?1:0,BOOMR.addVar(_)},rv:function(){var a=["ak.bpcip","ak.cport","ak.cr","ak.csrc","ak.gh","ak.ipv","ak.m","ak.n","ak.ol","ak.proto","ak.quicv","ak.tlsv","ak.0rtt","ak.r","ak.acc","ak.t","ak.tf"];BOOMR.removeVar(a)}};BOOMR.plugins.AK={akVars:_,akDNSPreFetchDomain:n,init:function(){if(!o.i){var a=BOOMR.subscribe;a("before_beacon",o.av,null,null),a("onbeacon",o.rv,null,null),o.i=!0}return this},is_complete:function(){return!0}}}}()}(window);</script></head>
  <body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N8B7PRZ"
      height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <div id="rLoadPage">
      <div id="rLoadBar" class="rLoadBar rLoadStart"></div>
    </div>
    <div id="app"></div>
    <script>window.global = window;</script>
    
  </body>
</html>